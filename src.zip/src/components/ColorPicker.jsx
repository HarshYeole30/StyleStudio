import React from 'react'
import { SketchPicker } from 'react-color'
import { useSnapshot } from 'valtio'

import state from '../store';

const ColorPicker = () => {
  const snap = useSnapshot(state);

  return (
    <div className="absolute left-full ml-3">
      <SketchPicker 
        color={snap.color}
        disableAlpha
        presetColors={['#d6e6ff','#e5d4ef','#74a892','#fdffb6','#9362ff','#ffffff','#101010']}
        onChange={(color) => state.color = color.hex}
      />
    </div>
  )
}

export default ColorPicker